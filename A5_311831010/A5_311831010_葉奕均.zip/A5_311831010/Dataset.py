from torch.utils.data import DataLoader, Dataset
from torchvision import transforms as xfms
import albumentations as A
import albumentations.pytorch.transforms as Atf
import os
import numpy as np
from PIL import Image
import cv2
import torch

class MyDataset(Dataset):
    def __init__(self, root_dir, split, first_transform=None, IMG_SIZE = [1200, 1600]):
        self.img_dir = root_dir+'/images'
        self.mask_dir = root_dir+'/masks'
        self.first_transform = first_transform
        self.train_set = {}
        self.test_set = {}
        self.split = split
        self.IMG_SIZE = IMG_SIZE

        for class_dir in os.listdir(self.img_dir):
            image_dir_path = os.path.join(self.img_dir, class_dir)
            mask_dir_path = os.path.join(self.mask_dir, class_dir)
            file_num = len(os.listdir(image_dir_path))
            for i, img_file in enumerate(os.listdir(image_dir_path)):

                name = img_file.split('.')[0]

                image_path = os.path.join(image_dir_path, f'{name}.jpg')

                mask_path = os.path.join(mask_dir_path, f'{name}.png')
                if i<= file_num*7//10:
                    self.train_set[image_path] = mask_path
                else:
                    self.test_set[image_path] = mask_path


        self.train_set = self.shuffle_(self.train_set)
        self.test_set = self.shuffle_(self.test_set)

    def shuffle_(self, dataset):
        shuffle_dic = list(dataset.items())
        np.random.shuffle(shuffle_dic)
        dataset = dict(shuffle_dic)
        return dataset

    def __len__(self):
        if self.split == 'train':
            return len(self.train_set)
        else:
            return len(self.test_set)

    def __getitem__(self, idx):

        if self.split == 'train':
            dataset = self.train_set
        else:
            dataset = self.test_set

        image_path = list(dataset)[idx]
        img = np.array(Image.open(image_path))
        mask_path = list(dataset.values())[idx]
        mask = Image.open(mask_path)
        mask = np.array(mask)

        # print(image_path)
        # print(mask_path)
        if self.split == 'train':
            for i in range(3000):
                random_crop =  A.Compose([
                                A.RandomCrop(width=self.IMG_SIZE[1], height=self.IMG_SIZE[0]),
                                A.Rotate(limit=360, p=0.9, border_mode=cv2.BORDER_CONSTANT),

                ],additional_targets={'image0': 'image', 'mask': 'image'})
                transformed = random_crop(image = img, mask = mask)

                if np.max(transformed["mask"])!=0:
                    break

            transformed = self.first_transform(image = transformed["image"], mask = transformed["mask"])
            img = transformed["image"]
            mask = transformed["mask"]

        img = Image.fromarray(img)
        img = xfms.ToTensor()(img).to(torch.float64)
        mask =  torch.from_numpy(mask).unsqueeze(0).to(torch.long)

        return img, mask